package com.example.pedidos;
// Archivo: Pedido.java
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Representa un pedido en el sistema.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Pedido {
    private String id;   // Identificador único del pedido
    private String cliente;  // Nombre del cliente que realizó el pedido
    private String producto;  // Nombre del producto pedido
    private int cantidad;   // Cantidad del producto pedido
}
