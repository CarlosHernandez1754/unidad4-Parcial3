package com.example.pedidos;

// Archivo: PedidoController.java
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Locale;
/**
 * Controlador REST que expone los endpoints para manejar pedidos.
 */
@RestController
@RequestMapping("/api/pedidos")
public class PedidoController {

    @Autowired
    private PedidoService pedidoService;

    @Autowired
    private MessageSource messageSource;
/**
     * Lista todos los pedidos.
     *
     * @return Un Flux que emite todos los pedidos.
     */
    @GetMapping
    public Flux<Pedido> listarPedidos() {
        return pedidoService.obtenerPedidos();
    }
     /**
     * Obtiene un pedido por su ID.
     *
     * @param id El ID del pedido a buscar.
     * @return Un Mono que emite el pedido encontrado, o un 404 si no existe.
     */
    @GetMapping("/{id}")
    public Mono<ResponseEntity<Pedido>> obtenerPedido(@PathVariable String id) {
        return pedidoService.obtenerPedidoPorId(id)
                .map(ResponseEntity::ok)
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }
/**
     * Crea un nuevo pedido.
     *
     * @param pedido El pedido a crear.
     * @param locale El locale para la internacionalización del mensaje de respuesta.
     * @return Un Mono que emite la respuesta con el mensaje de confirmación.
     */
    @PostMapping
    public Mono<ResponseEntity<String>> crearPedido(@RequestBody Pedido pedido,
                                                     @RequestHeader(name = "Accept-Language", required = false) Locale locale) {
        return pedidoService.crearPedido(pedido)
                .map(p -> ResponseEntity.status(HttpStatus.CREATED)
                        .body(messageSource.getMessage("pedido.creado", null, locale)));
    }
}