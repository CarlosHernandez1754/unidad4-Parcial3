package com.example.pedidos;

// Archivo: PedidoService.java
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Servicio que maneja la lógica de negocio de los pedidos.
 */
@Service
public class PedidoService {
    private final List<Pedido> pedidos = new ArrayList<>();
/**
     * Obtiene todos los pedidos de forma asíncrona.
     *
     * @return Un Flux que emite todos los pedidos.
     */
    public Flux<Pedido> obtenerPedidos() {
        // Simula una fuente de datos asíncrona con retardo
        return Flux.fromIterable(pedidos)
        .delayElements(Duration.ofMillis(100))
                .subscribeOn(Schedulers.boundedElastic());
    }
    /**
     * Crea un nuevo pedido de forma asíncrona.
     *
     * @param pedido El pedido a crear.
     * @return Un Mono que emite el pedido creado.
     */

    public Mono<Pedido> crearPedido(Pedido pedido) {
        return Mono.fromCallable(() -> {
            pedido.setId(UUID.randomUUID().toString());
            pedidos.add(pedido);
            return pedido;
        }).subscribeOn(Schedulers.boundedElastic());
    }
    /**
     * Obtiene un pedido por su ID de forma asíncrona.
     *
     * @param id El ID del pedido a buscar.
     * @return Un Mono que emite el pedido encontrado, o Mono.empty() si no existe.
     */

    public Mono<Pedido> obtenerPedidoPorId(String id) {
        return Flux.fromIterable(pedidos)
                .filter(pedido -> pedido.getId().equals(id))
                .next()
                .subscribeOn(Schedulers.boundedElastic());
    }
}
