package com.example.pedidos;

// Archivo: PedidoServiceTest.java
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import reactor.test.StepVerifier;
/**
 * Clase de pruebas unitarias para el servicio PedidoService.
 */
@SpringBootTest
public class PedidoServiceTest {

    @Autowired
    private PedidoService pedidoService;
/**
     * Prueba el método obtenerPedidos().
     */
    @Test
    public void testObtenerPedidos() {
        StepVerifier.create(pedidoService.obtenerPedidos())
                .expectNextCount(3) // Espera 3 pedidos (o el número que tengas)
                .expectComplete()
                .verify();
    }

    /**
     * Prueba el método crearPedido().
     */
    @Test
    public void testCrearPedido() {
        Pedido pedido = new Pedido("4","test","test",1);
        StepVerifier.create(pedidoService.crearPedido(pedido))
                .expectNextMatches(p -> p.getId() != null)
                .expectComplete()
                .verify();
    }
 /**
     * Prueba el método obtenerPedidoPorId().
     */
    @Test
    public void testObtenerPedidoPorId() {
        Pedido pedido = new Pedido("4","test","test",1);
        pedidoService.crearPedido(pedido).block();

        StepVerifier.create(pedidoService.obtenerPedidoPorId(pedido.getId()))
                .expectNextMatches(p -> p.getId().equals(pedido.getId()))
                .expectComplete()
                .verify();

    }
}